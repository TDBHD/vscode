-- AStA Bot Datenbankschema

CREATE TABLE IF NOT EXISTS admins (
    user_id     INTEGER PRIMARY KEY,
    username    TEXT,
    added_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    added_by    INTEGER
);

CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    chat_id     INTEGER NOT NULL,
    created_by  INTEGER NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active   BOOLEAN DEFAULT 1
);

CREATE TABLE IF NOT EXISTS votes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id),
    chat_id         INTEGER NOT NULL,
    message_id      INTEGER,               -- Telegram-Message-ID der Abstimmung
    title           TEXT NOT NULL,
    description     TEXT,                  -- Generierter Text aus Template
    vote_type       TEXT DEFAULT 'yna',    -- 'yna' (Ja/Nein/Enthaltung) oder 'multi'
    is_anonymous    BOOLEAN DEFAULT 1,
    is_open         BOOLEAN DEFAULT 1,
    top_number      INTEGER,
    template_name   TEXT,
    created_by      INTEGER NOT NULL,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    closed_at       DATETIME,
    deadline        DATETIME               -- optionale Laufzeit
);

CREATE TABLE IF NOT EXISTS ballots (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    vote_id     INTEGER NOT NULL REFERENCES votes(id),
    user_id     INTEGER,                   -- NULL wenn anonym gespeichert
    username    TEXT,                      -- NULL wenn anonym
    choice      TEXT NOT NULL,             -- 'yes', 'no', 'abstain', oder custom
    voted_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(vote_id, user_id)               -- Jeder nur einmal abstimmen
);

CREATE TABLE IF NOT EXISTS templates (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    template_text TEXT NOT NULL,           -- Text mit {platzhaltern}
    description TEXT,
    created_by  INTEGER NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bot_settings (
    key     TEXT PRIMARY KEY,
    value   TEXT
);

-- Standard-Einstellungen
INSERT OR IGNORE INTO bot_settings (key, value) VALUES ('language', 'de');
INSERT OR IGNORE INTO bot_settings (key, value) VALUES ('require_session', '0');
