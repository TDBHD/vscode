import aiosqlite
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

DB_PATH = os.getenv("DB_PATH", "asta_bot.db")
SCHEMA_PATH = Path(__file__).parent / "schema.sql"

_db_instance = None


async def get_db() -> aiosqlite.Connection:
    global _db_instance
    if _db_instance is None:
        _db_instance = await aiosqlite.connect(DB_PATH)
        _db_instance.row_factory = aiosqlite.Row
        await _db_instance.execute("PRAGMA journal_mode=WAL")
        await _db_instance.execute("PRAGMA foreign_keys=ON")
        await _init_schema(_db_instance)
    return _db_instance


async def _init_schema(db: aiosqlite.Connection):
    schema = SCHEMA_PATH.read_text()
    await db.executescript(schema)
    await db.commit()
    logger.info("Datenbankschema initialisiert.")


class Database:
    """Kontextmanager für DB-Transaktionen."""
    def __init__(self):
        self.db = None

    async def __aenter__(self):
        self.db = await get_db()
        return self.db

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            await self.db.rollback()
        else:
            await self.db.commit()
