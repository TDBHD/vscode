import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Config:
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    DB_PATH: str = os.getenv("DB_PATH", "asta_bot.db")
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LANGUAGE: str = os.getenv("LANGUAGE", "de")
    # Erste Admin-ID (Bootstrapping) – beim ersten Start setzen
    INITIAL_ADMIN_ID: int = int(os.getenv("INITIAL_ADMIN_ID", "0"))

config = Config()

# Abstimmungsoptionen
VOTE_OPTIONS = {
    "yna": {
        "yes":     {"de": "✅ Ja",          "en": "✅ Yes"},
        "no":      {"de": "❌ Nein",         "en": "❌ No"},
        "abstain": {"de": "🟡 Enthaltung",   "en": "🟡 Abstain"},
    },
    "yesno": {
        "yes": {"de": "✅ Ja",  "en": "✅ Yes"},
        "no":  {"de": "❌ Nein", "en": "❌ No"},
    },
}

CALLBACK_PREFIX = {
    "VOTE":     "vote",
    "SESSION":  "sess",
    "TEMPLATE": "tmpl",
    "CONFIRM":  "conf",
}
