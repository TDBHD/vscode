import logging
from functools import wraps
from telegram import Update
from telegram.ext import ContextTypes
from db import get_db
from config import config

logger = logging.getLogger(__name__)


async def is_admin(user_id: int) -> bool:
    """Prüft ob user_id in der Admintabelle steht oder INITIAL_ADMIN_ID ist."""
    if config.INITIAL_ADMIN_ID and user_id == config.INITIAL_ADMIN_ID:
        return True
    db = await get_db()
    async with db.execute("SELECT 1 FROM admins WHERE user_id = ?", (user_id,)) as cur:
        return await cur.fetchone() is not None


def require_admin(func):
    """Dekorator: Blockiert Handler wenn Nutzer kein Admin ist."""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if not await is_admin(user.id):
            from utils.i18n import t
            await update.message.reply_text(t("not_admin"), parse_mode="Markdown")
            logger.warning("Unberechtigter Zugriff von User %s (%s)", user.id, user.username)
            return
        return await func(update, context)
    return wrapper
