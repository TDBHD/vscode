import csv
import io
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def build_vote_keyboard(vote_id: int, vote_type: str = "yna", lang: str = "de") -> InlineKeyboardMarkup:
    """Baut Inline-Keyboard für eine Abstimmung."""
    labels = {
        "yna": [
            ("✅ Ja" if lang == "de" else "✅ Yes",        f"vote:{vote_id}:yes"),
            ("❌ Nein" if lang == "de" else "❌ No",        f"vote:{vote_id}:no"),
            ("🟡 Enthaltung" if lang == "de" else "🟡 Abstain", f"vote:{vote_id}:abstain"),
        ],
        "yesno": [
            ("✅ Ja" if lang == "de" else "✅ Yes", f"vote:{vote_id}:yes"),
            ("❌ Nein" if lang == "de" else "❌ No",  f"vote:{vote_id}:no"),
        ],
    }
    buttons = [InlineKeyboardButton(label, callback_data=cb)
               for label, cb in labels.get(vote_type, labels["yna"])]
    # 3er-Reihe für yna, 2er für yesno
    if vote_type == "yna":
        keyboard = [buttons]
    else:
        keyboard = [buttons]
    return InlineKeyboardMarkup(keyboard)


def format_results_markdown(vote: dict, counts: dict, ballots: list | None = None) -> str:
    """Formatiert Abstimmungsergebnis als Markdown-Text."""
    total = sum(counts.values())
    lines = [
        f"📊 *Ergebnis: {vote['title']}*",
        f"🆔 Abstimmung #{vote['id']}",
    ]
    if vote.get("description"):
        lines.append(f"_{vote['description']}_")
    lines.append("")

    labels = {"yes": "✅ Ja", "no": "❌ Nein", "abstain": "🟡 Enthaltung"}
    for choice, label in labels.items():
        n = counts.get(choice, 0)
        pct = (n / total * 100) if total > 0 else 0
        bar = "█" * int(pct / 10) + "░" * (10 - int(pct / 10))
        lines.append(f"{label}: *{n}* ({pct:.1f}%)\n`{bar}`")

    lines.append(f"\n👥 Gesamt: *{total}* Stimme(n)")

    # Beschluss ermitteln
    yes_count = counts.get("yes", 0)
    no_count = counts.get("no", 0)
    if yes_count > no_count:
        lines.append("🏛️ *→ ANGENOMMEN*")
    elif no_count > yes_count:
        lines.append("🏛️ *→ ABGELEHNT*")
    else:
        lines.append("🏛️ *→ STIMMENGLEICHHEIT*")

    # Namentliche Liste (nur nicht-anonym)
    if ballots:
        lines.append("\n*Namentliche Abstimmung:*")
        for b in ballots:
            choice_label = labels.get(b["choice"], b["choice"])
            name = b["username"] or f"User#{b['user_id']}"
            lines.append(f"• {name}: {choice_label}")

    return "\n".join(lines)


def format_results_csv(vote: dict, ballots: list) -> str:
    """Exportiert Abstimmungsergebnis als CSV-String."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ballot_id", "vote_id", "vote_title", "username", "user_id", "choice", "voted_at"])
    for b in ballots:
        writer.writerow([
            b["id"], b["vote_id"], vote["title"],
            b["username"] or "anonym", b["user_id"] or "anonym",
            b["choice"], b["voted_at"]
        ])
    return output.getvalue()
