import json
from pathlib import Path

_cache: dict[str, dict] = {}

def _load(lang: str) -> dict:
    if lang not in _cache:
        path = Path(__file__).parent.parent / "locales" / f"{lang}.json"
        if not path.exists():
            path = Path(__file__).parent.parent / "locales" / "de.json"
        _cache[lang] = json.loads(path.read_text(encoding="utf-8"))
    return _cache[lang]

def t(key: str, lang: str = "de", **kwargs) -> str:
    texts = _load(lang)
    template = texts.get(key, f"[{key}]")
    return template.format(**kwargs) if kwargs else template
