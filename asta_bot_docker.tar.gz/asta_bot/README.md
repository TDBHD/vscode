# AStA Abstimmungs-Bot

Telegram-Bot für strukturierte Abstimmungen in AStA-Gremiensitzungen.

## Schnellstart

```bash
pip install python-telegram-bot==20.7 aiosqlite
export BOT_TOKEN="dein_token_hier"
python main.py
```

## Architektur

```
asta_bot/
├── main.py                  # Einstiegspunkt, Bot-Konfiguration
├── config.py                # Konfiguration & Konstanten
├── handlers/
│   ├── __init__.py
│   ├── session_handler.py   # /create_session, /list_sessions
│   ├── vote_handler.py      # /vote, /close_vote, /results
│   ├── template_handler.py  # /create_template, /list_templates
│   └── admin_handler.py     # /addadmin, /removeadmin, /help
├── services/
│   ├── __init__.py
│   ├── session_service.py   # Session-Verwaltungslogik
│   ├── vote_service.py      # Abstimmungslogik (anonym/nicht-anonym)
│   └── template_service.py  # Vorlagenverwaltung & Rendering
├── db/
│   ├── __init__.py
│   ├── database.py          # DB-Verbindung & Initialisierung
│   └── schema.sql           # Datenbankschema
├── locales/
│   ├── de.json              # Deutsche Texte
│   └── en.json              # Englische Texte
└── utils/
    ├── __init__.py
    ├── formatters.py        # Ergebnisformatierung (Markdown/CSV)
    └── permissions.py       # Rollen & Berechtigungsprüfung
```

## Commands

| Command | Berechtigung | Beschreibung |
|---|---|---|
| `/create_session <Name>` | Admin | Neue Sitzung erstellen |
| `/list_sessions` | Alle | Aktive Sitzungen anzeigen |
| `/vote [template=X top=N name=Y betrag=Z]` | Admin | Abstimmung starten |
| `/close_vote <vote_id>` | Admin | Abstimmung beenden |
| `/results <vote_id>` | Alle (nach Abschluss) | Ergebnisse anzeigen |
| `/export <vote_id>` | Admin | Export als CSV/Markdown |
| `/create_template <name>` | Admin | Vorlage erstellen |
| `/list_templates` | Alle | Vorlagen anzeigen |
| `/addadmin <user_id>` | Admin | Admin hinzufügen |
| `/help` | Alle | Hilfe anzeigen |
