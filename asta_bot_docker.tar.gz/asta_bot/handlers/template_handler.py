import logging
from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, ConversationHandler, MessageHandler, filters, Application
from services import TemplateService
from utils import require_admin, t

logger = logging.getLogger(__name__)

# ConversationHandler-Zustände
TMPL_NAME, TMPL_TEXT, TMPL_DESC = range(3)


@require_admin
async def cmd_create_template(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Startet interaktiven Template-Erstellungsdialog."""
    args = context.args
    if args:
        context.user_data["tmpl_name"] = args[0].lower()
        await update.message.reply_text(
            f"✏️ Vorlage *{args[0]}* – Bitte Template-Text eingeben.\n\n"
            f"Nutze `{{platzhalter}}` für variable Felder, z.B.:\n"
            f"`Der AStA beschließt TOP {{top}} – {{name}} in Höhe von {{betrag}} €.`",
            parse_mode="Markdown"
        )
        return TMPL_TEXT
    await update.message.reply_text("✏️ Wie soll die Vorlage heißen? (z.B. `projektförderung`)")
    return TMPL_NAME


async def tmpl_receive_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["tmpl_name"] = update.message.text.strip().lower()
    await update.message.reply_text(
        f"✏️ Vorlage *{context.user_data['tmpl_name']}* – Bitte Template-Text eingeben.\n\n"
        "Nutze `{platzhalter}` für variable Felder.",
        parse_mode="Markdown"
    )
    return TMPL_TEXT


async def tmpl_receive_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["tmpl_text"] = update.message.text.strip()
    await update.message.reply_text("📝 Kurze Beschreibung (oder /skip):")
    return TMPL_DESC


async def tmpl_receive_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    desc = update.message.text.strip() if update.message.text != "/skip" else ""
    result = await TemplateService.create(
        name=context.user_data["tmpl_name"],
        template_text=context.user_data["tmpl_text"],
        description=desc,
        created_by=update.effective_user.id
    )
    if result.get("error") == "exists":
        await update.message.reply_text(t("template_exists", name=context.user_data["tmpl_name"]))
    else:
        await update.message.reply_text(t("template_created", name=result["name"]), parse_mode="Markdown")
    context.user_data.clear()
    return ConversationHandler.END


async def tmpl_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text("❌ Abgebrochen.")
    return ConversationHandler.END


async def cmd_list_templates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    templates = await TemplateService.list_all()
    if not templates:
        await update.message.reply_text(t("no_templates"))
        return
    lines = ["📋 *Verfügbare Vorlagen:*\n"]
    for tmpl in templates:
        desc = f" – _{tmpl['description']}_" if tmpl.get("description") else ""
        lines.append(f"• `{tmpl['name']}`{desc}")
        lines.append(f"  `{tmpl['template_text'][:80]}{'...' if len(tmpl['template_text'])>80 else ''}`")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


def template_router(app: Application):
    conv = ConversationHandler(
        entry_points=[CommandHandler("create_template", cmd_create_template)],
        states={
            TMPL_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, tmpl_receive_name)],
            TMPL_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, tmpl_receive_text)],
            TMPL_DESC: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, tmpl_receive_desc),
                CommandHandler("skip", tmpl_receive_desc),
            ],
        },
        fallbacks=[CommandHandler("cancel", tmpl_cancel)],
        name="create_template",
        persistent=False,
    )
    app.add_handler(conv)
    app.add_handler(CommandHandler("list_templates", cmd_list_templates))
