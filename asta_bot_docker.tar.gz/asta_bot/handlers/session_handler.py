import logging
from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, Application
from services import SessionService
from utils import require_admin, t

logger = logging.getLogger(__name__)


@require_admin
async def cmd_create_session(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Erstellt eine neue AStA-Sitzung."""
    args = context.args
    if not args:
        await update.message.reply_text(
            "❗ Bitte einen Namen angeben:\n`/create_session AStA Sitzung 12.06.2026`",
            parse_mode="Markdown"
        )
        return
    name = " ".join(args)
    session = await SessionService.create(
        name=name,
        chat_id=update.effective_chat.id,
        created_by=update.effective_user.id
    )
    await update.message.reply_text(
        t("session_created", name=session["name"], id=session["id"]),
        parse_mode="Markdown"
    )


async def cmd_list_sessions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Listet alle aktiven Sitzungen auf."""
    sessions = await SessionService.list_active(update.effective_chat.id)
    if not sessions:
        await update.message.reply_text(t("no_active_sessions"))
        return
    lines = ["📋 *Aktive Sitzungen:*\n"]
    for s in sessions:
        lines.append(f"• `#{s['id']}` – *{s['name']}* ({s['created_at'][:10]})")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


def session_router(app: Application):
    app.add_handler(CommandHandler("create_session", cmd_create_session))
    app.add_handler(CommandHandler("list_sessions", cmd_list_sessions))
    app.add_handler(CommandHandler("close_session", cmd_close_session))


@require_admin
async def cmd_close_session(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args or not args[0].isdigit():
        await update.message.reply_text("❗ Verwendung: `/close_session <id>`", parse_mode="Markdown")
        return
    await SessionService.close(int(args[0]))
    await update.message.reply_text(f"✅ Sitzung `{args[0]}` wurde geschlossen.", parse_mode="Markdown")
