import logging
import re
from db import get_db

logger = logging.getLogger(__name__)

PLACEHOLDER_RE = re.compile(r"\{(\w+)\}")


class TemplateService:
    @staticmethod
    async def create(name: str, template_text: str, description: str, created_by: int) -> dict:
        db = await get_db()
        try:
            async with db.execute(
                "INSERT INTO templates (name, template_text, description, created_by) VALUES (?,?,?,?)",
                (name.lower(), template_text, description, created_by)
            ) as cur:
                tid = cur.lastrowid
            await db.commit()
            logger.info("Vorlage erstellt: %s", name)
            return {"id": tid, "name": name}
        except Exception as e:
            if "UNIQUE" in str(e):
                return {"error": "exists"}
            raise

    @staticmethod
    async def get(name: str) -> dict | None:
        db = await get_db()
        async with db.execute(
            "SELECT * FROM templates WHERE name=?", (name.lower(),)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    @staticmethod
    async def list_all() -> list[dict]:
        db = await get_db()
        async with db.execute("SELECT id, name, description, template_text FROM templates ORDER BY name") as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def render(template_text: str, params: dict) -> tuple[str, list[str]]:
        """Rendert Template mit Parametern. Gibt (gerendeter Text, fehlende Felder) zurück."""
        placeholders = set(PLACEHOLDER_RE.findall(template_text))
        missing = [p for p in placeholders if p not in params and f"{p}?" not in template_text]
        # Optionale Platzhalter (z.B. {aenderungen?}) entfernen wenn nicht vorhanden
        text = template_text
        for p in placeholders:
            if p in params:
                text = text.replace(f"{{{p}}}", str(params[p]))
            else:
                text = re.sub(rf"\s*\{{?{p}\}}?[^\s]*", "", text)
        return text.strip(), missing
