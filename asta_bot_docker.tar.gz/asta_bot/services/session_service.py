import logging
from db import get_db

logger = logging.getLogger(__name__)


class SessionService:
    @staticmethod
    async def create(name: str, chat_id: int, created_by: int) -> dict:
        db = await get_db()
        async with db.execute(
            "INSERT INTO sessions (name, chat_id, created_by) VALUES (?, ?, ?)",
            (name, chat_id, created_by)
        ) as cur:
            session_id = cur.lastrowid
        await db.commit()
        logger.info("Sitzung erstellt: %s (ID=%s)", name, session_id)
        return {"id": session_id, "name": name}

    @staticmethod
    async def list_active(chat_id: int) -> list[dict]:
        db = await get_db()
        async with db.execute(
            "SELECT id, name, created_at FROM sessions WHERE chat_id=? AND is_active=1 ORDER BY created_at DESC",
            (chat_id,)
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    async def get_latest(chat_id: int) -> dict | None:
        db = await get_db()
        async with db.execute(
            "SELECT id, name FROM sessions WHERE chat_id=? AND is_active=1 ORDER BY created_at DESC LIMIT 1",
            (chat_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    @staticmethod
    async def close(session_id: int):
        db = await get_db()
        await db.execute("UPDATE sessions SET is_active=0 WHERE id=?", (session_id,))
        await db.commit()
