import logging
from datetime import datetime
from db import get_db

logger = logging.getLogger(__name__)


class VoteService:
    @staticmethod
    async def create(
        chat_id: int,
        session_id: int | None,
        title: str,
        description: str,
        vote_type: str,
        is_anonymous: bool,
        created_by: int,
        top_number: int | None = None,
        template_name: str | None = None,
        deadline: datetime | None = None,
    ) -> dict:
        db = await get_db()
        async with db.execute(
            """INSERT INTO votes
               (chat_id, session_id, title, description, vote_type, is_anonymous,
                created_by, top_number, template_name, deadline)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (chat_id, session_id, title, description, vote_type,
             int(is_anonymous), created_by, top_number, template_name,
             deadline.isoformat() if deadline else None)
        ) as cur:
            vote_id = cur.lastrowid
        await db.commit()
        logger.info("Abstimmung erstellt: %s (ID=%s, anonym=%s)", title, vote_id, is_anonymous)
        return {"id": vote_id, "title": title, "is_anonymous": is_anonymous}

    @staticmethod
    async def update_message_id(vote_id: int, message_id: int):
        db = await get_db()
        await db.execute("UPDATE votes SET message_id=? WHERE id=?", (message_id, vote_id))
        await db.commit()

    @staticmethod
    async def get(vote_id: int) -> dict | None:
        db = await get_db()
        async with db.execute("SELECT * FROM votes WHERE id=?", (vote_id,)) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    @staticmethod
    async def cast_ballot(vote_id: int, user_id: int, username: str | None, choice: str, is_anonymous: bool) -> dict:
        """Stimme abgeben. Gibt {'success': bool, 'error': str|None} zurück."""
        db = await get_db()
        # Bereits abgestimmt?
        async with db.execute(
            "SELECT 1 FROM ballots WHERE vote_id=? AND user_id=?", (vote_id, user_id)
        ) as cur:
            if await cur.fetchone():
                return {"success": False, "error": "already_voted"}

        stored_user_id = None if is_anonymous else user_id
        stored_username = None if is_anonymous else username

        try:
            await db.execute(
                "INSERT INTO ballots (vote_id, user_id, username, choice) VALUES (?,?,?,?)",
                (vote_id, stored_user_id, stored_username, choice)
            )
            # Für De-Duplikation auch bei anonym intern merken (aber nicht ausgeben)
            if is_anonymous:
                await db.execute(
                    "INSERT OR REPLACE INTO ballots (vote_id, user_id, username, choice) VALUES (?,?,?,?)",
                    (vote_id, user_id, None, choice)
                )
            await db.commit()
            return {"success": True, "error": None}
        except Exception as e:
            if "UNIQUE" in str(e):
                return {"success": False, "error": "already_voted"}
            logger.exception("Fehler beim Speichern der Stimme")
            return {"success": False, "error": str(e)}

    @staticmethod
    async def get_counts(vote_id: int) -> dict:
        db = await get_db()
        async with db.execute(
            "SELECT choice, COUNT(*) as cnt FROM ballots WHERE vote_id=? AND user_id IS NOT NULL GROUP BY choice",
            (vote_id,)
        ) as cur:
            rows = await cur.fetchall()
        # Bei anonym: user_id ist NULL für tatsächliche Stimmen, aber wir speichern user_id intern
        # Daher: für anonyme Abstimmungen alle Zeilen zählen
        async with db.execute(
            "SELECT choice, COUNT(*) as cnt FROM ballots WHERE vote_id=? GROUP BY choice",
            (vote_id,)
        ) as cur:
            all_rows = await cur.fetchall()
        return {r["choice"]: r["cnt"] for r in all_rows}

    @staticmethod
    async def get_ballots(vote_id: int) -> list[dict]:
        """Alle Stimmen (für nicht-anonyme Abstimmungen)."""
        db = await get_db()
        async with db.execute(
            "SELECT * FROM ballots WHERE vote_id=? AND user_id IS NOT NULL ORDER BY voted_at",
            (vote_id,)
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    async def close(vote_id: int):
        db = await get_db()
        await db.execute(
            "UPDATE votes SET is_open=0, closed_at=CURRENT_TIMESTAMP WHERE id=?",
            (vote_id,)
        )
        await db.commit()
        logger.info("Abstimmung %s geschlossen.", vote_id)
